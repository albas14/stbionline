<?php
$host='localhost';
$user='id3231518_root';
$pass='123456';
$database='id3231518_stbi';

$conn=new mysqli($host,$user,$pass,$database) or die('MySql Tidak Connect');
//mysql_select_db($database);

?>